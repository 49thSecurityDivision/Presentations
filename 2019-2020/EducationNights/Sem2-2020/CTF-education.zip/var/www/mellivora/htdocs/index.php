<?php
require('../include/mellivora.inc.php');

redirect(Config::get('MELLIVORA_CONFIG_INDEX_REDIRECT_TO'));