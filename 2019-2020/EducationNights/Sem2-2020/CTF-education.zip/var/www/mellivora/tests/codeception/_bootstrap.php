<?php

require_once('include/general.inc.php');