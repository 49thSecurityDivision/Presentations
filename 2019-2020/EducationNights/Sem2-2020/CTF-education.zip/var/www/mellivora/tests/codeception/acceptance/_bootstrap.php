<?php

// this user is created using sql in _data/sql/acceptance/*.sql
const CI_ADMIN_EMAIL = 'ci-admin@mellivora.co';
const CI_ADMIN_PASSWORD = 'password';

const CI_COMPETITOR_EMAIL = 'competitor@mellivora.co';
const CI_COMPETITOR_PASSWORD = 'password';

const CI_DEFAULT_CATEGORY_ID = 1;
const CI_DEFAULT_CATEGORY_TITLE = 'Default CI Category';

const CI_EDITABLE_CATEGORY_TITLE = 'Editable CI Category';
const CI_EDITABLE_CATEGORY_ID = 2;

const CI_DEFAULT_CHALLENGE_ID = 1;
const CI_DEFAULT_CHALLENGE_TITLE = 'Default CI Challenge';
const CI_DEFAULT_CHALLENGE_DESCRIPTION = 'This is the default CI Challenge';
const CI_DEFAULT_CHALLENGE_FLAG = 'abc123';

const CI_EDITABLE_CHALLENGE_TITLE = 'Editable CI Challenge';
const CI_EDITABLE_CHALLENGE_ID = 2;